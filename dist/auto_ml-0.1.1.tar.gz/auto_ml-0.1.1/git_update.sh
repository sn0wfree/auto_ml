#!/bin/bash

git add * && git commit -m" alter some and automatly update! " && git push automl v0.1.1

